function chama() {
    var selecto = selectzinho.value
    if (selecto == 'kid') {
        span.innerHTML = `<img src='https://c.tenor.com/LUpxLjk7f7UAAAAd/one-piece-eustass-kid.gif'>`
    }
    else if (selecto == 'zoro') {
        span.innerHTML = `<img src='https://i.pinimg.com/originals/a4/39/cd/a439cdfbfa00fcd19370fb594ef5de3b.gif'>`
    }
    else if (selecto == 'law') {
        span.innerHTML = `<img src='https://giffiles.alphacoders.com/354/35491.gif'>`
    }
    else if (selecto == 'luffy') {
        span.innerHTML = `<img src='https://c.tenor.com/YNhKSlGrgxsAAAAC/one-piece-luffy.gif'>`
    }

}
